package com.example.r_square

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
