import 'package:get/get.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:r_square/app/modules/admin_app/bottom_nav_bar/admin_bottom_bar.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/login/login_binding/login_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/login/view/login_screen.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/signup/binding/signup_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/signup/view/signup_screen.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/dashboard/binding/admin_dashboard_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/dashboard/view/admin_dashboard.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/leads/leads_screen.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/listings/view/listing_details.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/listings/view/listing_screen.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/binding/affiliates_dashboard_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/view/affiliates_dashboard.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/executives/binding/executives_dashboard_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/executives/view/executives_dashboard.dart';
import 'package:r_square/app/modules/admin_app/screens/onBoarding/onBoarding_binding/onboarding_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/onBoarding/views/onBoarding1.dart';
import 'package:r_square/app/modules/admin_app/screens/slpash/slpash_screen.dart';
import 'package:r_square/app/modules/admin_app/screens/slpash/splash_binding.dart';
import 'package:r_square/app/modules/common/choose_role/binding/choose_role_binding.dart';
import 'package:r_square/app/modules/common/choose_role/view/choose_role.dart';
import 'package:r_square/app/routes/app_routes.dart';

class AppPages {
  static const initial = AppRoutes.splash;

  static final routes = [
    GetPage(
        name: AppRoutes.splash,
        page: () => SplashScreen(),
        binding: SplashBinding()),

    GetPage(
      name: AppRoutes.onboarding,
      page: () => OnboardingScreen(),
      binding: OnboardingBinding(),
    ),

    GetPage(
      name: AppRoutes.chooseRole,
      page: () => ChooseRole(),
      binding: ChooseRoleBinding(),
    ),
    GetPage(
        name: AppRoutes.login,
        page: () => LoginScreen(),
        binding: LoginBinding()),
        GetPage(name: AppRoutes.signUp, page: () => SignupScreen(),binding: SignupBinding()),
    GetPage(
      name: AppRoutes.adminDashborad,
      page: () => AdminDashboard(),
      binding: AdminDashboardBinding(),
    ),
    GetPage(
      name: AppRoutes.affiliatesDashboard,
      page: () => AffiliatesDashboard(),
      binding: AffiliatesDashboardBinding(),
    ),GetPage(
      name: AppRoutes.executivesDashborad,
      page: () => ExecutivesDashboard(),
      binding: ExecutivesDashboardBinding(),
    ),GetPage(
      name: AppRoutes.listingScreen,
      page: () => ListingScreen(),
      // binding: AdminDashboardBinding(),
    ),GetPage(
      name: AppRoutes.leadsScreen,
      page: () => LeadsScreen(),
      // binding: AdminDashboardBinding(),
    ),
    GetPage(
      name: AppRoutes.customAdminBottomBar,
      page: () => BottomNavBarScreen(),
      // binding: AdminDashboardBinding(),
    ),
    GetPage(
      name: AppRoutes.listingDetails,
      page: () => ListingDetails(),
      // binding: AdminDashboardBinding(),
    ),
  ];
}
