class AppRoutes {
  static const splash = '/splash';
  static const chooseRole = '/Choose-role';
  static const onboarding ='/onboarding';
static const String login = '/login';
static const String signUp = '/sign-up';
static const String forgotPassword = '/forgot-password';
static const String adminDashborad = '/admin-dashboard';
static const String affiliatesDashboard = '/affiliates-dashboard';
static const String executivesDashborad = '/executives-dashboard';
static const String listingScreen = '/listing-screen';
static const String leadsScreen = '/leads-screen';

static const String customAdminBottomBar='/custom-admin-bottom-bar';
static const String listingDetails='/listing-details';
// static const String home = '/home';
// static const String profile = '/profile';
// static const String settings = '/settings';
// static const String notifications = '/notifications';
// static const String help = '/help';
// static const String about = '/about';
// static const String contactUs = '/contact-us';
// static const String termsAndConditions = '/terms-and-conditions';
// static const String privacyPolicy = '/privacy-policy';
// static const String faq = '/faq';
// static const String signIn = '/sign-in';
// static const String signUpAs = '/sign-up-as';

// static const String signUpAsAdmin = '/sign-up-as-admin';
// static const String signUpAsAffiliate = '/sign-up-as-affiliate';
// static const String signUpAsExecutive = '/sign-up-as-executive';
// static const String signUpAsUser = '/sign-up-as-user';
// static const String signUpAsCustomer = '/sign-up-as-customer';
// static const String signUpAsVendor = '/sign-up-as-vendor';









   static const String signInAs = '/sign-in-as';







 
}