import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/modules/admin_app/bottom_nav_bar/controller/custom_bottom_bar_controller.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/dashboard/binding/admin_dashboard_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/dashboard/view/admin_dashboard.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/leads/leads_screen.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/listings/view/listing_screen.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/binding/affiliates_dashboard_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/view/affiliates_dashboard.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/executives/binding/executives_dashboard_binding.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/executives/view/executives_dashboard.dart';
import 'package:r_square/app/routes/app_routes.dart';

class BottomNavBarScreen extends StatelessWidget {
  final BottomNavController controller = Get.put(BottomNavController());

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final isFirstRouteInCurrentTab = !await (controller
                .navigatorKeys[controller.currentIndex.value].currentState
                ?.maybePop() ??
            Future.value(false));
        if (isFirstRouteInCurrentTab) {
          return true;
        }
        return false;
      },
      child: Scaffold(
        body: Obx(() => IndexedStack(
              index: controller.currentIndex.value,
              children: controller.navigatorKeys.map((key) {
                final index = controller.navigatorKeys.indexOf(key);
                return Navigator(
                  key: key,
                  initialRoute: controller.initialRoutes[index],
                  onGenerateRoute: (settings) {
                    switch (settings.name) {
                      case AppRoutes.adminDashborad:
                        return GetPageRoute(
                            page: () => AdminDashboard(),
                            binding: AdminDashboardBinding());
                      case AppRoutes.affiliatesDashboard:
                        return GetPageRoute(
                            page: () => AffiliatesDashboard(),
                            binding: AffiliatesDashboardBinding());
                      case AppRoutes.executivesDashborad:
                        return GetPageRoute(
                            page: () => ExecutivesDashboard(),
                            binding: ExecutivesDashboardBinding());
                      case AppRoutes.listingScreen:
                        return GetPageRoute(
                          page: () => ListingScreen(),
                        );
                      case AppRoutes.leadsScreen:
                        return GetPageRoute(
                          page: () => LeadsScreen(),
                        );
                      default:
                        return null;
                    }
                  },
                );
              }).toList(),
            )),
        bottomNavigationBar: Obx(() => BottomNavigationBar(
              backgroundColor: AppColors.primarywhiteColor,
              currentIndex: controller.currentIndex.value,
              onTap: controller.changeTab,
              selectedItemColor: AppColors.primaryBlackColor,
              unselectedItemColor: Colors.grey,
              type: BottomNavigationBarType.fixed,
              selectedFontSize: 14.sp,
              items:const [
                BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
                BottomNavigationBarItem(
                    icon: Icon(Icons.group), label: "Affiliates"),
                BottomNavigationBarItem(
                    icon: Icon(Icons.business), label: "Executives"),
                BottomNavigationBarItem(
                    icon: Icon(Icons.list), label: "Listings"),
                BottomNavigationBarItem(
                    icon: Icon(Icons.person), label: "Leads"),
              ],
            )),
      ),
    );
  }
}
