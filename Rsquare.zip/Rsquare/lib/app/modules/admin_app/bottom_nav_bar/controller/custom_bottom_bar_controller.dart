import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:r_square/app/routes/app_routes.dart';

class BottomNavController extends GetxController {
  RxInt currentIndex = 0.obs;

  final List<GlobalKey<NavigatorState>> navigatorKeys = [
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),

  ];

  final List<String> initialRoutes = [
    AppRoutes.adminDashborad,
    AppRoutes.affiliatesDashboard,
    AppRoutes.executivesDashborad,
    AppRoutes.listingScreen,
    AppRoutes.leadsScreen,
  ];

  void changeTab(int index) {
    print("Navigating to tab: $index, route: ${initialRoutes[index]}");
    if (currentIndex.value != index) {
      currentIndex.value = index;
    } else {
      navigatorKeys[index].currentState?.popUntil((route) => route.isFirst);
    }
  }
}