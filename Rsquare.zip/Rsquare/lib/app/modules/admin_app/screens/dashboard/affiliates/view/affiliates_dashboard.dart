import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/core/widgets/primary_button.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/dashboard/controller/admin_dashboard_controller.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/controller/affiliates_dashboard_controller.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/widget/active_affilites_card.dart';

class AffiliatesDashboard extends StatelessWidget {
  final controller = Get.find<AffiliatesDashboardController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        automaticallyImplyLeading: false,
        title: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0),
          child: CText(
            text: "Affiliates",
            fontSize: 25.sp,
            fontWeight: FontWeight.w800,
            color: AppColors.primaryappcolor,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GridView.count(
                shrinkWrap: true,
                crossAxisCount: 2,
                childAspectRatio: 1.78,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: [
                  DashboardCard(
                  
                     title: 'Active Affiliates', value: '247',
                  ),
                  DashboardCard(
                title:     "Pending Payouts",
                 value:    "₹ 12,480",
                  ),
                  DashboardCard(
                title:     "Tasks",
                  value:   "8",
                  ),
                  DashboardCard(
             title:        "Recent Leads",
               value:      "34",
                  ),
                ],
              ),
              SizedBox(height: 24.h),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  PrimaryButton(
                      text: 'Process Payouts',
                      width: 166.w,
                      height: 45.h,
                      onTap: () {}),
                  PrimaryButton(
                      text: 'Add Affiliate',
                      width: 166.w,
                      height: 45.h,
                      onTap: () {})
                ],
              ),
              SizedBox(height: 20.h),
              CText(
                text: "Active Affilites",
                fontSize: 22.sp,
                fontWeight: FontWeight.w800,
                color: AppColors.primaryBlackColor,
              ),
              SizedBox(height: 12.h),
              // Card(
              //   color: AppColors.white,
              //
              //   child: Container(
              //     // height: 120.h,
              //     child: Padding(
              //       padding: const EdgeInsets.all(16.0),
              //       child: Column(
              //         children: [
              //           Row(
              //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //             children: [
              //               CText(
              //                 text: 'Sarah Thompson',
              //                 fontSize: 22.sp,
              //                 color: AppColors.primaryBlackColor,
              //               ),
              //               PrimaryButton(
              //                   text: 'Active',
              //                   width: 54.w,
              //                   height: 28.h,
              //                   color: AppColors.greencolor,
              //                   textColor: Colors.green,
              //                   onTap: () {})
              //             ],
              //           ),
              //           SizedBox(
              //             height: 8.h,
              //           ),
              //           Row(
              //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //             children: [
              //               CText(
              //                 text: 'Total Leads: 156',
              //                 fontSize: 18.sp,
              //                 color: AppColors.darkgrey,
              //               ),
              //               CText(
              //                 text: 'Pendings: ₹ 890',
              //                 fontSize: 18.sp,
              //                 color: AppColors.darkgrey,
              //               ),
              //             ],
              //           ),
              //           SizedBox(
              //             height: 8.h,
              //           ),
              //           Row(
              //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //             children: [
              //               Row(
              //                 children:[
              //              const     Icon(
              //                     Icons.visibility,
              //                     color: AppColors.primaryBlackColor,
              //                   ),
              //                   CText(
              //                     text: 'View',
              //                     fontSize: 18.sp,
              //                     color: AppColors.primaryBlackColor,
              //                   ),
              //                   SizedBox(
              //                     width: 8.w,
              //                   ),
              //              const     Icon(
              //                     Icons.edit_square,
              //                     color: AppColors.primaryBlackColor,
              //                   ),
              //                   CText(
              //                     text: 'Edit',
              //                     fontSize: 18.sp,
              //                     color: AppColors.primaryBlackColor,
              //                   ),
              //                 ],
              //               ),
              //               Row(
              //                 children: [
              //              const     Icon(
              //                     Icons.delete,
              //                     color: Colors.red,
              //                   ),
              //                   CText(
              //                     text: 'Delete',
              //                     fontSize: 18.sp,
              //                     color: Colors.red,
              //                   ),
              //                 ],
              //               )
              //             ],
              //           ),
              //         ],
              //       ),
              //     ),
              //   ),
              // ),

              ActiveAffilitesCard(
                  name: "Sarah Thompson",
                  totalLeads: 156,
                  pendings: 890,
                  isActive: true,
                  onView: () {},
                  onEdit: () {},
                  onDelete: () {}),

              ActiveAffilitesCard(
                  name: "Michael Chen",
                  totalLeads: 89,
                  pendings: 450,
                  isActive: true,
                  onView: () {},
                  onEdit: () {},
                  onDelete: () {}),
              _buildLeadList(),

              // _buildLeadList("James Wilson", "Luxury Villa Project",
              //     "Site Visit Done", Colors.greenAccent),

              // _buildLead("Emily Thompson", "Skyline Apartments",
              //     "Call Scheduled", Colors.lightBlueAccent),
              // _buildLead("Michael Brown", "Green Valley Homes", "Pending",
              //     Colors.yellowAccent),
              SizedBox(height: 16.h),
              CText(
                text: "Today's Tasks",
                fontSize: 20.sp,
                fontWeight: FontWeight.w800,
                color: AppColors.primaryBlackColor,
              ),
              Card(
                color: AppColors.white,
          
                child: ListTile(
                  leading: Icon(
                    Icons.calendar_today,
                    color: AppColors.primaryBlackColor,
                  ),
                  title: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CText(
                        text: 'Site Visit - Project Aurora',
                        fontSize: 18,
                        color: AppColors.primaryBlackColor,
                        fontWeight: FontWeight.w600,
                      ),
                      CText(
                        text: '10:30 AM with James Wilson',
                        fontSize: 16,
                        color: AppColors.darkgrey,
                        fontWeight: FontWeight.w400,
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                color: AppColors.white,
          
                child: ListTile(
                  leading: Icon(
                    Icons.inventory_outlined,
                    color: AppColors.primaryBlackColor,
                  ),
                  title: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CText(
                        text: 'Invoice Generation',
                        fontSize: 18,
                        color: AppColors.primaryBlackColor,
                        fontWeight: FontWeight.w600,
                      ),
                      CText(
                        text: 'Skyline Properties - ₹ 12,000',
                        fontSize: 16,
                        color: AppColors.darkgrey,
                        fontWeight: FontWeight.w400,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 14.h),
              CText(
                text: "Pending Payouts",
                fontSize: 20.sp,
                fontWeight: FontWeight.w800,
                color: AppColors.primaryBlackColor,
              ),

              SizedBox(height: 6.h),
              Card(
                color: AppColors.white,
                
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CText(
                            text: 'Emily Thompson',
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: AppColors.primaryBlackColor,
                          ),
                          CText(
                            text: '₹780',
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: AppColors.primaryBlackColor,
                          ),
                        ],
                      ),
                      SizedBox(height: 8.h),
                      CText(
                        text: 'Requested on 12th July 2021',
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: AppColors.primaryBlackColor,
                      ),
                      SizedBox(height: 12.h),
                      Center(
                          child: PrimaryBorderButton(
                              text: "View Details",
                              width: 152.w,
                              height: 38.h,
                              color: Colors.grey,
                              textColor: AppColors.primaryBlackColor,
                              onTap: () {}))
                    ],
                  ),
                ),
              ),
              SizedBox(height: 6.h),
              Card(
                color: AppColors.white,
                
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CText(
                            text: 'David Parker',
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: AppColors.primaryBlackColor,
                          ),
                          CText(
                            text: '₹1,200',
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: AppColors.primaryBlackColor,
                          ),
                        ],
                      ),
                      SizedBox(height: 8.h),
                      CText(
                        text: 'Requested on 16th July 2022',
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: AppColors.primaryBlackColor,
                      ),
                      SizedBox(height: 12.h),
                      Center(
                          child: PrimaryBorderButton(
                              text: "View Details",
                              width: 152.w,
                              height: 38.h,
                              color: Colors.grey,
                              textColor: AppColors.primaryBlackColor,
                              onTap: () {}))
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }


  Widget _buildLeadList() {
    return Card(
      color: AppColors.primarywhiteColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.r),
      ),

      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CText(
                    text: "Recent Leads",
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryBlackColor,
                  ),
                  CText(
                    text: 'View All',
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: AppColors.primaryBlackColor,
                  ),
                ],
              ),
            ),
            _buildLead("James Wilson", "Luxury Villa Project",
                "Site Visit Done", AppColors.greencolor),
            _buildLead("Emily Thompson", "Skyline Apartments", "Call Scheduled",
                AppColors.lightblue),
            _buildLead("Michael Brown", "Green Valley Homes", "Pending",
                AppColors.lightorgan),
          ],
        ),
      ),
    );
  }

  Widget _buildLead(String name, String project, String status, Color bgColor) {
    Color textColor = status == "Pending"
        ? Colors.orange
        : status == "Site Visit Done"
            ? Colors.green
            : Colors.blue;

    return Column(
      children: [
        ListTile(
          title: CText(
            text: name,
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppColors.primaryBlackColor,
          ),
          subtitle: CText(
            text: project,
            fontSize: 12.sp,
            fontWeight: FontWeight.w400,
            color: AppColors.primaryBlackColor,
          ),
          trailing: Chip(
            label: CText(
              text: status,
              fontSize: 12.sp,
              color: textColor,
            ),
            backgroundColor: bgColor,
          ),
        ),
        Divider(color: AppColors.dividercolor),
      ],
    );
  }
}
