import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AdminDashboardController extends GetxController {
  // Add your controller variables and methods here

  @override
  void onInit() {
    super.onInit();
    // Initialize your variables or fetch data here
  }


  @override
  void onReady() {
    super.onReady();
    // Called after the widget is rendered on screen
  }

  @override
  void onClose() {
    // Clean up resources here
    super.onClose();
  }

var selectedTask = ''.obs;

  void toggleTask(String task) {
    if (selectedTask.value == task) {
      selectedTask.value = ''; // Uncheck if already selected
    } else {
      selectedTask.value = task; // Select the new task
    }
  }

}