import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/constants/app_images.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/routes/app_routes.dart';

class ListingScreen extends StatelessWidget {
  final List<Map<String, dynamic>> properties = [
    {
      "id": "PRO-2024-001",
      "title": "The Riverside Residences",
      "address": "123 Waterfront Drive, Marina Bay",
      "type": "Apartment",
      "size": "750 - 1100 sq.ft",
      "price": "₹ 450,000 - ₹ 650,000",
      "image": AppImages.oceanImg,
      
    },
    {
      "id": "PRO-2024-002",
      "title": "Marina Heights",
      "address": "456 Marina View, Downtown",
      "type": "Apartment",
      "size": "900 - 1500 sq.ft",
      "price": "₹ 550,000 - ₹ 850,000",
      "image": AppImages.propertyImg
    },
    {
      "id": "PRO-2024-003",
      "title": "Palm Villa Estate",
      "address": "789 Sunset Boulevard, Beachside",
      "type": "Villa",
      "size": "1200 - 2500 sq.ft",
      "price": "₹ 750,000 - ₹ 1,200,000",
      "image": AppImages.propertyImg
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: CText(
            text: "Listings",
            fontWeight: FontWeight.w800,
            fontSize: 25.sp,
            color: AppColors.primaryappcolor),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      backgroundColor: AppColors.backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: properties.length,
                itemBuilder: (context, index) {
                  return propertyCard(properties[index], () {
                 
                  });
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(50.r)),
        onPressed: () {},
        backgroundColor: AppColors.primaryappcolor,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  /// **Property Card Widget**
  Widget propertyCard(Map<String, dynamic> property, Function? onTap) {
    return GestureDetector(
      onTap: onTap as void Function()?,
      child: Card(
        
        color: AppColors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// **Property Title & Image**
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CText(
                            text: property["title"],
                            color: AppColors.primaryBlackColor,
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w700),
                        SizedBox(height: 4.h),
                        CText(
                            text: property["id"],
                            color: AppColors.darkgrey,
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600),
                      ],
                    ),
                  ),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.asset(property["image"],
                        width: 60.w, height: 60.h, fit: BoxFit.cover),
                  ),
                ],
              ),
              const SizedBox(height: 8),
      
              /// **Address & Property Details**
              Row(
                children: [
                  Icon(Icons.location_on, size: 16.w, color: AppColors.darkgrey),
                  SizedBox(width: 4.h),
                  Expanded(
                      child: CText(
                          text: property["address"],
                          color: AppColors.primaryBlackColor,
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600)),
                ],
              ),
              Row(
                children: [
                  Icon(Icons.apartment, size: 16.w, color: AppColors.darkgrey),
                  SizedBox(width: 4.w),
                  CText(
                    text: property["type"],
                    fontSize: 16.sp,
                    color: AppColors.primaryBlackColor,
                    fontWeight: FontWeight.w600,
                  ),
                ],
              ),
              Row(
                children: [
                  const Icon(Icons.straighten, size: 16, color: AppColors.darkgrey),
                  const SizedBox(width: 4),
                  CText(
                      text: property["size"],
                      fontSize: 16.sp,
                      color: AppColors.primaryBlackColor,
                      fontWeight: FontWeight.w600),
                ],
              ),
              Row(
                children: [
                  const Icon(Icons.price_change, size: 16, color: AppColors.darkgrey),
                  const SizedBox(width: 4),
                  CText(
                      text: property["price"],
                      color: Colors.black,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600),
                ],
              ),
              const SizedBox(height: 8),
      
              /// **View Details Button**
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                       Get.toNamed(AppRoutes.listingDetails);
                  },
                  icon: const Icon(Icons.remove_red_eye, size: 18),
                  label: CText(
                    text: "View Details",
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColors.white,
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryappcolor,
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
