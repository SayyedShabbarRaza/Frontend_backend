import 'package:get/get.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/controller/affiliates_dashboard_controller.dart';

class ExecutivesDashboardController extends GetxController{
  
}