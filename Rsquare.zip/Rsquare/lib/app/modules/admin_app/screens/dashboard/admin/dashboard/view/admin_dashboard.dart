import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/dashboard/controller/admin_dashboard_controller.dart';

class AdminDashboard extends StatelessWidget {
  final controller = Get.find<AdminDashboardController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        automaticallyImplyLeading: false,
        title: CText(
          text: "Dashboard",
          fontSize: 25.sp,
          fontWeight: FontWeight.w800,
          color: AppColors.primaryappcolor,
        ),
        actions: [
          Stack(children: [
            IconButton(
                icon: Icon(
                  Icons.notifications,
                  color: AppColors.primaryblackColor,
                ),
                onPressed: () {}),
            Positioned(
              right: 10,
              top: 10,
              child: CircleAvatar(
                radius: 9,
                backgroundColor: Colors.red,
                child: CText(
                  text: "3",
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primarywhiteColor,
                ),
              ),
            ),
          ]),
          IconButton(
              icon: Icon(
                Icons.person,
                color: AppColors.primaryBlackColor,
              ),
              onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Divider(
                color: AppColors.dividercolor,
              ),
              GridView.count(
                shrinkWrap: true,
                crossAxisCount: 2,
                childAspectRatio: 1.78,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: [
                  _buildCard("Total Affiliates", "156", Icons.people),
                  _buildCard("Active Listings", "89", Icons.list),
                  _buildCard("Pending Payouts", "₹ 45.2K", Icons.money),
                  _buildCard("Tasks", "12", Icons.task),
                ],
              ),
              SizedBox(height: 20),
              _buildLeadList(),
              

              // _buildLeadList("James Wilson", "Luxury Villa Project",
              //     "Site Visit Done", Colors.greenAccent),

              // _buildLead("Emily Thompson", "Skyline Apartments",
              //     "Call Scheduled", Colors.lightBlueAccent),
              // _buildLead("Michael Brown", "Green Valley Homes", "Pending",
              //     Colors.yellowAccent),
              SizedBox(height: 20),
              _buildTask([
                "Site visit for Luxury Villa Project",
                "Raise invoice for Skyline Apartments",
                "Follow up with pending leads",
              ])
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard(String title, String value, IconData icon) {
    return Card(
      elevation: 3,
      color: AppColors.primarywhiteColor,
      shadowColor: AppColors.primarywhiteColor,
      child: Padding(
        padding: const EdgeInsets.all(13.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CText(
                  text: title,
                  fontSize: 15.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.darkgrey,
                ),
                Icon(
                  icon,
                  color: AppColors.primaryBlackColor,
                ),
              ],
            ),
            CText(
              text: value,
              color: AppColors.primaryBlackColor,
              fontSize: 20.sp,
              fontWeight: FontWeight.w800,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLeadList() {
    return Card(
      color: AppColors.primarywhiteColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.r),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CText(
                    text: "Recent Leads",
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryBlackColor,
                  ),
                  CText(
                    text: 'View All',
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: AppColors.primaryBlackColor,
                  ),
                ],
              ),
            ),
            _buildLead("James Wilson", "Luxury Villa Project",
                "Site Visit Done", AppColors.greencolor),
            _buildLead("Emily Thompson", "Skyline Apartments", "Call Scheduled",
                AppColors.lightblue),
            _buildLead("Michael Brown", "Green Valley Homes", "Pending",
                AppColors.lightorgan),
          ],
        ),
      ),
    );
  }

  Widget _buildLead(String name, String project, String status, Color bgColor) {
    Color textColor = status == "Pending"
        ? Colors.orange
        : status == "Site Visit Done"
            ? Colors.green
            : Colors.blue;

    return Column(
      children: [
        ListTile(
          title: CText(
            text: name,
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppColors.primaryBlackColor,
          ),
          subtitle: CText(
            text: project,
            fontSize: 12.sp,
            fontWeight: FontWeight.w400,
            color: AppColors.primaryBlackColor,
          ),
          trailing: Chip(
            label: CText(
              text: status,
              fontSize: 12.sp,
              color: textColor,
            ),
            backgroundColor: bgColor,
          ),
        ),
        Divider(color: AppColors.dividercolor),
      ],
    );
  }

  Widget _buildTask(List<String> tasks) {
    return Card(
      color: AppColors.primarywhiteColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.r),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CText(
                    text: "Today's Tasks",
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryBlackColor,
                  ),
                  CText(
                    text: 'View All',
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: AppColors.primaryBlackColor,
                  ),
                ],
              ),
            ),
            Obx(() => Column(
                  children: tasks.map((task) {
                    return CheckboxListTile(
                      side: const BorderSide(color: AppColors.darkgrey),
                      title: CText(
                        text: task,
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w600,
                        color: AppColors.primaryBlackColor,
                      ),
                      activeColor: AppColors.primaryappcolor,
                      checkColor: AppColors.white,
                      tileColor: controller.selectedTask.value == task
                          ? AppColors.primaryappcolor.withOpacity(0.1)
                          : Colors.transparent,
                      selectedTileColor: AppColors.primaryappcolor,
                      overlayColor:
                          MaterialStateProperty.all(AppColors.primaryappcolor),
                      controlAffinity: ListTileControlAffinity.leading,
                      value: controller.selectedTask.value == task,
                      onChanged: (value) {
                        controller.toggleTask(task);
                      },
                    );
                  }).toList(),
                )),
          ],
        ),
      ),
    );
  }
}
