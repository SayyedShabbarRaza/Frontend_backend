import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/core/widgets/primary_button.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/widget/active_affilites_card.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/executives/controller/executives_dashboard_controller.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/executives/widget/recent_activity_widget.dart';

class ExecutivesDashboard extends StatelessWidget {
  final controller = Get.find<ExecutivesDashboardController>();

  ExecutivesDashboard({super.key});

  final List<Map<String, dynamic>> callHistory = [
    {
      "title": "Call completed with John Smith",
      "subtitle": "2 minutes ago",
      "icon": Icons.call,
      "iconBgColor": AppColors.boxcolor,
      "iconColor": AppColors.primaryBlackColor,
    },
    {
      "title": "Site visit confirm Mark Wilson",
      "subtitle": "15 minutes ago",
      "icon": Icons.check,
      "iconBgColor": Colors.green.shade100,
      "iconColor": Colors.green,
    },
    {
      "title": "New affiliate added : Alex",
      "subtitle": "10 minutes ago",
      "icon": Icons.person_add,
      "iconBgColor": Colors.red.shade100,
      "iconColor": Colors.red,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        automaticallyImplyLeading: false,
        title: CText(
          text: "Executives",
          fontSize: 25.sp,
          fontWeight: FontWeight.w800,
          color: AppColors.primaryappcolor,
        ),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: Icon(Icons.notifications, color: AppColors.primaryblackColor),
                onPressed: () {},
              ),
              Positioned(
                right: 10,
                top: 10,
                child: CircleAvatar(
                  radius: 9,
                  backgroundColor: Colors.red,
                  child: CText(
                    text: "3",
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColors.primarywhiteColor,
                  ),
                ),
              ),
            ],
          ),
          IconButton(
            icon: Icon(Icons.person, color: AppColors.primaryBlackColor),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Divider(color: AppColors.dividercolor),
              GridView.count(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                childAspectRatio: 1.78,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: [
                  DashboardCard(title: "Total Executives", value: "24"),
                  DashboardCard(title: "Total Affiliates", value: "18"),
                ],
              ),
              SizedBox(height: 20),
              PrimaryButton(
                text: 'Process Payouts',
                width: double.infinity,
                onTap: () {},
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  PrimaryBorderButton(
                    text: 'All Status',
                    width: 167.w,
                    height: 38.h,
                    color: AppColors.darkgrey,
                    textColor: AppColors.primaryBlackColor,
                    onTap: () {},
                  ),
                  PrimaryBorderButton(
                    text: 'All Executives',
                    textColor: AppColors.primaryBlackColor,
                    width: 167.w,
                    height: 38.h,
                    color: AppColors.darkgrey,
                    onTap: () {},
                  ),
                ],
              ),
              SizedBox(height: 16.h),
              CText(
                text: "Recent Activities",
                fontSize: 18.sp,
                fontWeight: FontWeight.w700,
                color: AppColors.primaryBlackColor,
              ),
              SizedBox(height: 10),

              /// **Recent Calls List**
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.30, 
                child: ListView.builder(
                  itemCount: callHistory.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return callCard(
                      title: callHistory[index]["title"],
                      subtitle: callHistory[index]["subtitle"],
                      icon: callHistory[index]["icon"],
                      iconBgColor: callHistory[index]["iconBgColor"],
                      iconColor: callHistory[index]["iconColor"],
                    );
                  },
                ),
              ),

              
            ],
          ),
        ),
      ),
    );
  }



  // Widget _buildSectionTitle(String title) {
  //   return CText(
  //     text: title,
  //     fontSize: 18.sp,
  //     fontWeight: FontWeight.w700,
  //     color: AppColors.primaryBlackColor,
  //   );
  // }


}
