import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/constants/app_images.dart';
import 'package:r_square/app/core/widgets/custom_appbar.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/core/widgets/custom_textfield.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/listings/controller/listing_controller.dart';

class ListingDetails extends StatelessWidget {
  ListingDetails({super.key});
  final ListingController controller = Get.put(ListingController());
  final List<String> types = ["School", "Hospital", "Restaurant"];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: CustomAppBar(text: 'Listing Details'),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14.0),
          child: Column(
            children: [
              Card(
                color: AppColors.white,
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CText(
                            text: 'Basic Information',
                            fontSize: 22.sp,
                            color: AppColors.primaryBlackColor,
                            fontWeight: FontWeight.w600,
                          ),
                          SizedBox(
                            height: 10.h,
                          ),
                          CText(
                            text: 'Property Code',
                            fontSize: 18.sp,
                            color: AppColors.darkgrey,
                            fontWeight: FontWeight.w600,
                          ),
                          SizedBox(
                            height: 5.h,
                          ),
                          SecondCustomTextField(
                            controller: TextEditingController(),
                            hintText: '12345',
                            keyboardType: TextInputType.number,
                            textcolor: AppColors.darkgrey,
                          ),
                          SizedBox(
                            height: 10.h,
                          ),
                          CText(
                            text: 'Project Name',
                            fontSize: 18.sp,
                            color: AppColors.darkgrey,
                            fontWeight: FontWeight.w600,
                          ),
                          SizedBox(
                            height: 5.h,
                          ),
                          SecondCustomTextField(
                            controller: TextEditingController(),
                            hintText: 'The Riverside Residences',
                            keyboardType: TextInputType.number,
                            textcolor: AppColors.darkgrey,
                          ),
                          SizedBox(
                            height: 10.h,
                          ),
                          CText(
                            text: 'Property Type',
                            fontSize: 18.sp,
                            color: AppColors.darkgrey,
                            fontWeight: FontWeight.w600,
                          ),
                          SizedBox(
                            height: 5.h,
                          ),
                          SecondCustomTextField(
                            controller: TextEditingController(),
                            hintText: 'Property Type',
                            keyboardType: TextInputType.number,
                            textcolor: AppColors.darkgrey,
                            suffixIcon: Icon(
                              Icons.keyboard_arrow_down_outlined,
                              color: AppColors.primaryappcolor,
                              size: 24.w,
                            ),
                            hasSuffix: true,
                          ),
                          SizedBox(
                            height: 10.h,
                          ),
                          CText(
                            text: 'Images & videos',
                            fontSize: 18.sp,
                            color: AppColors.darkgrey,
                            fontWeight: FontWeight.w600,
                          ),
                          SizedBox(
                            height: 5.h,
                          ),
                          SizedBox(
                            height: 90.h,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: 9,
                              itemBuilder: (context, index) {
                                return Padding(
                                  padding: EdgeInsets.only(right: 10.w),
                                  child: Image.asset(
                                    AppImages.propertyImg,
                                    width: 70.w,
                                    height: 70.h,
                                  ),
                                );
                              },
                            ),
                          ),
                          CText(
                            text: 'Location',
                            fontSize: 18.sp,
                            color: AppColors.darkgrey,
                            fontWeight: FontWeight.w600,
                          ),
                          SizedBox(
                            height: 5.h,
                          ),
                          SecondCustomTextField(
                            controller: TextEditingController(),
                            hintText: '113 Waterworks Road, Ashgrove QLD 4060',
                            keyboardType: TextInputType.number,
                            textcolor: AppColors.darkgrey,
                            preffixIcon: Icon(
                              Icons.location_on_outlined,
                              color: AppColors.primaryappcolor,
                              size: 24.w,
                            ),
                            hasPreffix: true,
                          ),
                          SizedBox(
                            height: 16.h,
                          ),
                          Container(
                              width: double.infinity,
                              height: 122.h,
                              child: GoogleMap(
                                  initialCameraPosition: CameraPosition(
                                      target: LatLng(31.5204, 74.3587),
                                      zoom: 14))),
                          SizedBox(
                            height: 22.h,
                          ),
                          CText(
                            text: 'REAR Number',
                            fontSize: 18.sp,
                            color: AppColors.darkgrey,
                            fontWeight: FontWeight.w600,
                          ),
                          SizedBox(
                            height: 5.h,
                          ),
                          SecondCustomTextField(
                            controller: TextEditingController(),
                            hintText: 'REARA20020XYZ',
                            keyboardType: TextInputType.number,
                            textcolor: AppColors.darkgrey,
                            preffixIcon: Icon(
                              Icons.location_on_outlined,
                              color: AppColors.primaryappcolor,
                              size: 24.w,
                            ),
                            hasPreffix: true,
                          ),
                          SizedBox(
                            height: 10.h,
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20.h,
              ),
              Card(
                color: AppColors.white,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CText(
                        text: 'Nearby Places',
                        fontSize: 20.sp,
                        color: AppColors.primaryBlackColor,
                        fontWeight: FontWeight.w600,
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      CText(
                        text: 'Types',
                        fontSize: 18.sp,
                        color: AppColors.darkgrey,
                        fontWeight: FontWeight.w600,
                      ),
                      SizedBox(
                        height: 5.h,
                      ),
                      Obx(() => SizedBox(
                            width: double.infinity,
                            child: DropdownButton<String>(
                              value:
                                  types.contains(controller.selectedType.value)
                                      ? controller.selectedType.value
                                      : null,
                              iconEnabledColor: AppColors.darkgrey,
                              icon: Icon(
                                Icons.keyboard_arrow_down_sharp,
                              ),
                              iconSize: 26.w,
                              dropdownColor: AppColors.boxcolor,
                              isExpanded: true,
                              hint: CText(
                                text: 'Select Type',
                                fontSize: 18.sp,
                                color: AppColors.darkgrey,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              items: types.map((String type) {
                                return DropdownMenuItem<String>(
                                  value: type,
                                  child: CText(
                                    text: type,
                                    color: AppColors.darkgrey,
                                    fontSize: 18.sp,
                                  ),
                                );
                              }).toList(),
                              onChanged: (newValue) {
                                if (newValue != null) {
                                  controller.selectedType(newValue);
                                }
                              },
                            ),
                          )),
                      CText(
                        text: 'Name',
                        fontSize: 18.sp,
                        color: AppColors.darkgrey,
                        fontWeight: FontWeight.w600,
                      ),
                      SizedBox(
                        height: 5.h,
                      ),
                      SecondCustomTextField(
                        controller: TextEditingController(),
                        hintText: 'Enter name',
                        keyboardType: TextInputType.number,
                        textcolor: AppColors.darkgrey,
                      ),
                      SizedBox(
                        height: 10.h,
                      ),
                      CText(
                        text: 'Distance',
                        fontSize: 18.sp,
                        color: AppColors.darkgrey,
                        fontWeight: FontWeight.w600,
                      ),
                      SizedBox(
                        height: 5.h,
                      ),
                      SecondCustomTextField(
                        controller: TextEditingController(),
                        hintText: 'Enter Distance',
                        keyboardType: TextInputType.number,
                        textcolor: AppColors.darkgrey,
                      ),
                      SizedBox(
                        height: 10.h,
                      ),
                      CText(
                        text: 'Upload Image',
                        fontSize: 18.sp,
                        color: AppColors.darkgrey,
                        fontWeight: FontWeight.w600,
                      ),
                      SizedBox(
                        height: 5.h,
                      ),
                      DottedBorder(
                        color: Colors.grey,
                        strokeWidth: 2,
                        dashPattern: [6, 4],
                        borderType: BorderType.RRect,
                        radius: Radius.circular(10),
                        child: Container(
                          width: double.infinity,
                          height: 130.h,
                          alignment: Alignment.center,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.cloud_upload,
                                  color: AppColors.darkgrey),
                              SizedBox(height: 8.h),
                              CText(
                                text: 'Click to upload or drag and drop',
                                fontSize: 18.sp,
                                color: AppColors.darkgrey,
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10.h,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20.h,),
              Card(color: AppColors.white,child:Column(
                children: [
                     CText(
                                text: 'Click to upload or drag and drop',
                                fontSize: 18.sp,
                                color: AppColors.darkgrey,
                              ),
                ],
              ) ,)
            ],
          ),
        ),
      ),
    );
  }
}
