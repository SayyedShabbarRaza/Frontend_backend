import 'package:get/get.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/affiliates/controller/affiliates_dashboard_controller.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/executives/controller/executives_dashboard_controller.dart';

class ExecutivesDashboardBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ExecutivesDashboardController>(() => ExecutivesDashboardController());
  }
}