import 'package:flutter/material.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';

import '../../../../../../core/constants/app_colors.dart';

Widget callCard({
  required String title,
  required String subtitle,
  required IconData icon,
  required Color iconBgColor,
  required Color iconColor,
}) {
  return Card(
    color: AppColors.white,
    child: ListTile(
      leading: CircleAvatar(
        backgroundColor: iconBgColor,
        child: Icon(icon, color: iconColor),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          CText(
            text: title,
            fontSize: 18,
            color: AppColors.primaryBlackColor,
            fontWeight: FontWeight.w600,
          ),
          CText(
            text: subtitle,
            fontSize: 16,
            color: AppColors.darkgrey,
            fontWeight: FontWeight.w400,
          ),
        ],
      ),
    ),
  );
}
