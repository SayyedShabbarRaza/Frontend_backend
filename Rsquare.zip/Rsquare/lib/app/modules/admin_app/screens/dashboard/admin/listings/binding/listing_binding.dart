import 'package:get/get.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/listings/controller/listing_controller.dart';

class ListingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ListingController>(() => ListingController());
  }
}