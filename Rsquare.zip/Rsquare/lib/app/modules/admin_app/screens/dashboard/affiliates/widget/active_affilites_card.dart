import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';

class ActiveAffilitesCard extends StatelessWidget {
  final String name;
  final int totalLeads;
  final double pendings;
  final bool isActive;
  final VoidCallback onView;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const ActiveAffilitesCard({
    Key? key,
    required this.name,
    required this.totalLeads,
    required this.pendings,
    required this.isActive,
    required this.onView,
    required this.onEdit,
    required this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            /// Name & Status
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
                  decoration: BoxDecoration(
                    color: isActive ? AppColors.greencolor : Colors.red,
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Text(
                    isActive ? 'Active' : 'Inactive',
                    style: TextStyle(
                      color: Colors.green,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 8.h),

            /// Total Leads & Pending Amount
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Total Leads: $totalLeads',
                  style: TextStyle(fontSize: 18.sp, color: Colors.grey),
                ),
                Text(
                  'Pendings: ₹$pendings',
                  style: TextStyle(fontSize: 18.sp, color: Colors.grey),
                ),
              ],
            ),

            SizedBox(height: 8.h),

            /// Actions
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.visibility, color:AppColors.headingcolor),
                    SizedBox(width: 4.w),
                    GestureDetector(
                      onTap: onView,
                      child: Text(
                        'View',
                        style: TextStyle(fontSize: 18.sp, color: AppColors.headingcolor),
                      ),
                    ),
                    SizedBox(width: 16.w),
                    Icon(Icons.edit_square, color: AppColors.darkgrey),
                    SizedBox(width: 4.w),
                    GestureDetector(
                      onTap: onEdit,
                      child: Text(
                        'Edit',
                        style: TextStyle(fontSize: 18.sp, color: AppColors.darkgrey),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.delete, color: Colors.red),
                    SizedBox(width: 4.w),
                    GestureDetector(
                      onTap: onDelete,
                      child: Text(
                        'Delete',
                        style: TextStyle(fontSize: 18.sp, color: Colors.red),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


class DashboardCard extends StatelessWidget {
  final String title; 
  final String value;
   Color? color;
   VoidCallback? onTap;

   DashboardCard({
    Key? key,
    required this.title,
    required this.value,
     this.color,
     this.onTap,
  }) : super(key: key);

  @override

  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child:Card(

      color: AppColors.primarywhiteColor,
      shadowColor: AppColors.primarywhiteColor,
      child: Padding(
        padding: const EdgeInsets.all(13.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CText(
                  text: title,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.darkgrey,
                ),
              ],
            ),
            CText(
              text: value,
              color: AppColors.primaryBlackColor,
              fontSize: 20.sp,
              fontWeight: FontWeight.w800,
            ),
          ],
        ),
      ),
    ),
    );
  }

}

