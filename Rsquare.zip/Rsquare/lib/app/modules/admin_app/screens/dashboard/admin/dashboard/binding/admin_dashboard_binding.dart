import 'package:get/get.dart';
import 'package:r_square/app/modules/admin_app/screens/dashboard/admin/dashboard/controller/admin_dashboard_controller.dart';

class AdminDashboardBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AdminDashboardController>(() => AdminDashboardController());
  }
}