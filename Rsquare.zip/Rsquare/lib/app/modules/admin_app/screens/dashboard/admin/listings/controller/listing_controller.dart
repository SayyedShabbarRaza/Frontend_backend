import 'package:get/get.dart';

class ListingController extends GetxController {
  
  var listings = [].obs;


  
  var selectedType = "Select Type".obs;


  void fetchListings() {
    // Add your logic to fetch listings here
    // For example, you can make an API call and update the listings variable
  }

  @override
  void onInit() {
    super.onInit();
    // Fetch listings when the controller is initialized
    fetchListings();
  }

  @override
  void onClose() {
    // Clean up resources when the controller is disposed
    super.onClose();
  }
}