import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:r_square/app/core/utils/shared_pref_services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashController extends GetxController
    with GetSingleTickerProviderStateMixin {
  late AnimationController animationController;

  @override
  void onInit() {
    super.onInit();
    animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..forward();

    _navigateToNextScreen();
  }

  void _navigateToNextScreen() {

    Timer(const Duration(seconds: 3), () async{
       Get.offAllNamed('/onboarding');
// 
      // var loggedIn = await   SharePrefServices.getLoggInUserIsGenral();

      // if (loggedIn == null) {
      //   // Get.offAllNamed('/sign-in-as');
      // } else {
      //   // Get.offAllNamed(AppRoutes.bottomNav);
      // }

    });
  }

  @override
  void onClose() {
    animationController.dispose();
    super.onClose();
  }
}