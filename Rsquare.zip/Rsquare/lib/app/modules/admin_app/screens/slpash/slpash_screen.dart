

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/constants/app_images.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/modules/admin_app/screens/slpash/slpash_controller.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SplashController>();

    return Scaffold(
      body: Center(
        child: ScaleTransition(
          scale: controller.animationController.drive(CurveTween(curve: Curves.easeIn)),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                AppImages.bgimage,
                fit: BoxFit.cover,
              ),
              Container(
                color: AppColors.primaryappcolor.withOpacity(0.5),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    AppImages.appLogo,
                    height: 200.h,
                    width: 200.w,
                  ),
                  SizedBox(
                    width: 190.w,
                    child: CText(
                      text: 'Rsquare Real Estate',
                      color: Colors.white,
                      fontSize: 24.sp,
                      maxLines: 2,
                      alignText: TextAlign.center,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
