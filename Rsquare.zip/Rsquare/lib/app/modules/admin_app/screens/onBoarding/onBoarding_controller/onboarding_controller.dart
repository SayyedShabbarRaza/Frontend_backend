import 'package:get/get.dart';
import 'package:r_square/app/routes/app_routes.dart';

class OnboardingController extends GetxController {
  var currentIndex = 0.obs;




  void nextPage() {
    if (currentIndex.value < 2) {
      currentIndex.value++;
    } else {
      Get.offAllNamed(AppRoutes.chooseRole);
      // Get.offAllNamed('/ch'); // Navigate to home or login screen
    }
  }

  void skipOnboarding() {
      Get.offAllNamed(AppRoutes.chooseRole);

  }
}
