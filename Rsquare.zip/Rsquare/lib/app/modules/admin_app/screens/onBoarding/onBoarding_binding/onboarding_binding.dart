import 'package:get/get.dart';
import 'package:r_square/app/modules/admin_app/screens/onBoarding/onBoarding_controller/onboarding_controller.dart';

class OnboardingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<OnboardingController>(() => OnboardingController());
  }
}
