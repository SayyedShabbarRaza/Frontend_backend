import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/constants/app_images.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/core/widgets/primary_button.dart';
import 'package:r_square/app/modules/admin_app/screens/onBoarding/onBoarding_controller/onboarding_controller.dart';

class OnboardingScreen extends StatelessWidget {
  final List<Map<String, String>> onboardingData = [
    {
      "image": AppImages.onBoarding,
      "title": "Earn up to ₹40,000 when someone buys a home",
      "description":
          "Share their details and earn up to ₹40,000 when they book. No effort, just rewards."
    },
    {
      "image": AppImages.onBoarding2,
      "title": "We Do the Work You Share, We Handle the Rest",
      "description":
          "Our dedicated executive will track your lead and update you until they book."
    },
    {
      "image": AppImages.onBoarding3,
      "title": "Start Earning Today Simple & Rewarding!",
      "description":
          "Just refer, relax, and earn big when your lead books a home."
    },
  ];

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<OnboardingController>();

    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.primarybackgroundcolor,
        body: Obx(
          () => Column(
            children: [
              Expanded(
                child: PageView.builder(
                  onPageChanged: (index) =>
                      controller.currentIndex.value = index,
                  itemCount: onboardingData.length,
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Stack(
                          children: [
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 20.0.w, vertical: 20.h),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(25.r),
                                child: Image.asset(
                                  onboardingData[index]["image"]!,
                                  width: Get.width,
                                  fit: BoxFit.cover,
                                  height: 405.h,
                                ),
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                    vertical:
                                        MediaQuery.of(context).size.height *
                                            0.01,
                                    horizontal:
                                        MediaQuery.of(context).size.width *
                                            0.03,
                                  ),
                                  child: Image.asset(
                                    AppImages.appLogo,
                                    width: 100.w,
                                    height: 100.h,
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                    vertical:
                                        MediaQuery.of(context).size.height *
                                            0.01,
                                    horizontal:
                                        MediaQuery.of(context).size.width *
                                            0.08,
                                  ),
                                  child: PrimaryButton(
                                    color: AppColors.greyColorDD,
                                    textColor: AppColors.primaryblackColor,
                                    width: 86.w,
                                    height: 38.h,
                                    radius: 50.r,
                                    text: 'Skip',
                                    onTap: () {
                                      controller.skipOnboarding();
                                      controller.skipOnboarding();
                                      
                                    },
                                  ),
                                ),
                              ],
                            ),
                            Obx(
                              () => Positioned(
                                top: MediaQuery.of(context).size.height * 0.50,
                                left: (MediaQuery.of(context).size.width -
                                        (onboardingData.length * 30.w)) /
                                    2,
                                child: Row(
                                  children: List.generate(
                                    onboardingData.length,
                                    (index) => Container(
                                      margin:
                                          EdgeInsets.symmetric(horizontal: 3.w),
                                      width: 30.w,
                                      height: 2.h,
                                      color:
                                          controller.currentIndex.value >= index
                                              ? Colors.white
                                              : Colors.white.withOpacity(0.5),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 20.h),
                        SizedBox(
                          width: 335.w,
                          child: CText(
                            maxLines: 2,
                            alignText: TextAlign.left,
                            text: onboardingData[index]["title"]!,
                            fontSize: 25.sp,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primaryappcolor,
                          ),
                        ),
                        SizedBox(height: 10.h),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 30.w),
                          child: Text(
                            onboardingData[index]["description"]!,
                            textAlign: TextAlign.left,
                            style:
                                TextStyle(fontSize: 16.sp, color: Colors.grey),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
              SizedBox(height: 30.h),
              SizedBox(
                width: 300.w,
                height: 50.h,
                child: ElevatedButton(
                  onPressed: controller.nextPage,
                  child: Text(
                    controller.currentIndex.value == onboardingData.length - 1
                        ? "Start Now"
                        : "Next",
                    style: TextStyle(fontSize: 18.sp),
                  ),
                ),
              ),
              SizedBox(height: 40.h),
            ],
          ),
        ),
      ),
    );
  }
}
