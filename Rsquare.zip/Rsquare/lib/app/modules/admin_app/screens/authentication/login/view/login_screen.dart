import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/constants/app_images.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/core/widgets/custom_textfield.dart';
import 'package:r_square/app/core/widgets/primary_button.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/login/login_controller/login_controller.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/signup/view/signup_screen.dart';
import 'package:r_square/app/routes/app_routes.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    LoginController loginController = Get.put(LoginController());
    return Scaffold(
      backgroundColor: AppColors.primarybackgroundcolor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 10),
                height: 180.h,
                child: Image.asset(AppImages.loginImg),
              ),
              SizedBox(height: 20.h),
              Container(
                margin: const EdgeInsets.only(left: 20),
                height: 85.h,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CText(
                          text: 'Let\'s ',
                          fontSize: 25,
                          fontWeight: FontWeight.w500,
                          color: AppColors.headingcolor,
                        ),
                        CText(
                          text: 'Sign In',
                          fontSize: 25,
                          fontWeight: FontWeight.w800,
                          color: AppColors.primaryappcolor,
                        ),
                      ],
                    ),
                    SizedBox(height: 10.h),
                    SizedBox(
                      width: 400.w,
                      child: CText(
                        text: 'quis nostrud exercitation ullamco laboris nisi ut',
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w400,
                        color: AppColors.primaryappcolor,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10.h),
              Container(
                width: 350.w,
                child: Column(
                  children: [
                    CustomTextField(
                      controller: TextEditingController(),
                      hintText: 'Email',
                      hasPreffix: true,
                      // height: 70.h, // Adjusted height
                      preffixIcon: Icon(
                        Icons.email_outlined,
                        color: AppColors.headingcolor,
                      ),
                      keyboardType: TextInputType.emailAddress, textcolor: AppColors.headingcolor,
                    ),
                    SizedBox(height: 10.h), // Reduced space
                    Obx(()=>CustomTextField(
                      controller: TextEditingController(),
                      hintText: 'Password',
                      hasPreffix: true,
                      // height: 90.h, // Adjusted height
                      preffixIcon: Icon(
                        Icons.lock_outline,
                        color: AppColors.headingcolor,
                      ),
                      hasSuffix: true,
                      isPassword: loginController.isPassword.value,
                      suffixIcon: GestureDetector(
                          onTap: () {
                            loginController.togglePassword();
                          },
                          child: Icon(loginController.isPassword.value
                              ? Icons.visibility
                              : Icons.visibility_off,color: AppColors.primaryappcolor,)),
                      keyboardType: TextInputType.visiblePassword, textcolor: AppColors.headingcolor,
                    ),),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(top: 5.h),
                        child: GestureDetector(
                          onTap: () => Get.toNamed(AppRoutes.forgotPassword),
                          child: CText(
                            text: 'Forgot password?',
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w600,
                            color: AppColors.primaryappcolor,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 40.h),
              PrimaryButton(
                text: 'Next',
                onTap: () {
                  // Get.toNamed(AppRoutes.adminDashborad);
                  Get.toNamed(AppRoutes.customAdminBottomBar);
                },
                width: 190.w,
                height: 60.h,
                color: AppColors.primaryappcolor,
              ),
              SizedBox(height: 25.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CText(
                    text: 'Don’t have an account? ',
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColors.headingcolor,
                  ),
                  GestureDetector(
                    onTap: () => Get.toNamed(AppRoutes.signUp
                        ), // Navigate to Register
                    child: CText(
                      text: 'Register',
                      fontSize: 13.sp,
                      fontWeight: FontWeight.w800,
                      color: AppColors.primaryappcolor,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
