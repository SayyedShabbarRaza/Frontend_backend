import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/core/widgets/custom_textfield.dart';
import 'package:r_square/app/core/widgets/primary_button.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/login/login_controller/login_controller.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/signup/signup_controller/signup_controller.dart';

class SignupScreen extends StatelessWidget {
  const SignupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    SignupController signupController = Get.put(SignupController());

    return Scaffold(
        backgroundColor: AppColors.primarybackgroundcolor,
        body: SafeArea(
          child: Padding(
              padding: EdgeInsets.only(top: 20.h, left: 20.w),
              child: SingleChildScrollView(
                child: Column(children: [
                  Row(
                    children: [
                      Container(
                        height: 48.h,
                        width: 48.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.lightgrey,
                        ),
                        child: GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Icon(
                              Icons.arrow_back_ios_new_outlined,
                              color: AppColors.primaryBlackColor,
                              size: 15,
                            )),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 40.h,
                  ),
                  Container(
                    height: 85.h,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            CText(
                              text: 'Create Your ',
                              fontSize: 25,
                              fontWeight: FontWeight.w500,
                              color: AppColors.headingcolor,
                            ),
                            CText(
                              text: 'account',
                              fontSize: 25,
                              fontWeight: FontWeight.w800,
                              color: AppColors.primaryappcolor,
                            ),
                          ],
                        ),
                        SizedBox(height: 10.h),
                        SizedBox(
                          width: 400.w,
                          child: CText(
                            text:
                                'quis nostrud exercitation ullamco laboris nisi ut',
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: AppColors.primaryappcolor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 40.h,
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 20.w),
                    width: 380.w,
                    child: Column(
                      children: [
                        CustomTextField(
                          controller: TextEditingController(),
                          hintText: 'Full name',
                          hasPreffix: true,
                          preffixIcon: Icon(
                            Icons.person_outlined,
                            color: AppColors.headingcolor,
                          ),
                          keyboardType: TextInputType.emailAddress,
                          textcolor: AppColors.headingcolor,
                        ),
                        SizedBox(height: 10.h),
                        CustomTextField(
                          controller: TextEditingController(),
                          hintText: 'Email',
                          hasPreffix: true,
                          preffixIcon: Icon(
                            Icons.email_outlined,
                            color: AppColors.headingcolor,
                          ),
                          keyboardType: TextInputType.emailAddress,
                          textcolor: AppColors.headingcolor,
                        ),
                        SizedBox(height: 10.h),
                        Obx(
                          () => CustomTextField(
                            controller: TextEditingController(),
                            hintText: 'Password',
                            hasPreffix: true,
                            preffixIcon: Icon(
                              Icons.lock_outline,
                              color: AppColors.headingcolor,
                            ),
                            hasSuffix: true,
                            isPassword: signupController.isPassword.value,
                            suffixIcon: GestureDetector(
                                onTap: () {
                                  signupController.togglePassword();
                                },
                                child: Icon(signupController.isPassword.value
                                    ? Icons.visibility
                                    : Icons.visibility_off)),
                            keyboardType: TextInputType.visiblePassword,
                            textcolor: AppColors.headingcolor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20.h,
                  ),
                  PrimaryButton(
                    text: 'Next',
                    onTap: () {},
                    width: 190.w,
                    height: 60.h,
                    color: AppColors.primaryappcolor,
                  ),
                ]),
              )),
        ));
  }
}
