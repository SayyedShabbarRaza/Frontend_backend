import 'package:get/get.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/login/login_controller/login_controller.dart';

class LoginBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<LoginController>(() => LoginController());
  }
}