import 'package:get/get.dart';
import 'package:r_square/app/modules/admin_app/screens/authentication/signup/signup_controller/signup_controller.dart';

class SignupBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SignupController>(() => SignupController());
  }
}