import 'package:get/get.dart';

class SignupController extends GetxController {
  var isLoading = false.obs;
  var email = ''.obs;
  var password = ''.obs;
  var confirmPassword = ''.obs;
  RxBool isPassword = true.obs;

  void togglePassword() {
    isPassword.value = !isPassword.value;
  }

  void signup() async {
    if (password.value != confirmPassword.value) {
      Get.snackbar('Error', 'Passwords do not match');
      return;
    }

    isLoading.value = true;

    try {
      Get.snackbar('Success', 'Signup successful');
    } catch (e) {
      Get.snackbar('Error', e.toString());
    } finally {
      isLoading.value = false;
    }
  }
}
