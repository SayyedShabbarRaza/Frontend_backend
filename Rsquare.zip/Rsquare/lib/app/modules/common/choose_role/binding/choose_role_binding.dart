import 'package:get/get.dart';
import 'package:r_square/app/modules/common/choose_role/controller/choose_role_controller.dart';

class ChooseRoleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ChooseRoleController>(() => ChooseRoleController());
  }
}
