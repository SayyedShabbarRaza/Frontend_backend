import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/constants/app_images.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/core/widgets/primary_button.dart';
import 'package:r_square/app/modules/common/choose_role/controller/choose_role_controller.dart';
import 'package:r_square/app/modules/common/choose_role/widget/role_selection_tile.dart';
import 'package:r_square/app/routes/app_routes.dart';

class ChooseRole extends StatelessWidget {
  ChooseRole({super.key});
  final controller = Get.find<ChooseRoleController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primarybackgroundcolor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          children: [
            Image.asset(
              AppImages.appLogo,
              width: 140.w,
              height: 148.h,
            ),
            CText(
              text: 'Rsquare',
              fontSize: 25.sp,
              fontWeight: FontWeight.w800,
              color: AppColors.primaryappcolor,
            ),
            SizedBox(
              height: 43.h,
            ),
            Row(
              children: [
                CText(
                  text: 'Choose your ',
                  fontSize: 25.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColors.primaryappcolor,
                ),
                CText(
                  text: 'role',
                  fontSize: 25.sp,
                  fontWeight: FontWeight.w800,
                  color: AppColors.primaryappcolor,
                ),
              ],
            ),
            SizedBox(height: 11.h),

            RoleSelectionTile(
              title: 'Admin',
              icon: Icons.person,
              controller: controller,
            ),
            SizedBox(height: 15.h),
            RoleSelectionTile(
              title: 'Affiliate',
              icon: Icons.group,
              controller: controller,
            ),
            SizedBox(height: 15.h),
            RoleSelectionTile(
              title: 'Executive',
              icon: Icons.work,
              controller: controller,
            ),
         Spacer(),
            PrimaryButton(
                text: 'Next', width: 190.w, height: 54.h, onTap: () {
                  Get.toNamed(AppRoutes.login);
                }),
            SizedBox(
              height: 20.h,
            ),

            // Container(
            //       width:Get.width,
            //       height: 70.h,
            //       decoration: BoxDecoration(
            //         color: AppColors.grey,
            //         borderRadius: BorderRadius.circular(10.r),
            //       ),
            //       child: ListTile(
            //      leading   : Icon(Icons.person,color: AppColors.primaryappcolor,),
            //         title: CText(
            //           text: 'Admin',
            //           fontSize: 14.sp,
            //           fontWeight: FontWeight.w400,
            //           color: AppColors.primaryappcolor,
            //         ),

            //         trailing: Radio(
            //           value: 1,
            //           groupValue: 1,
            //           onChanged: (value) {},
            //         ),
            //       ),

            //     )
          ],
        ),
      ),
    );
  }
}
