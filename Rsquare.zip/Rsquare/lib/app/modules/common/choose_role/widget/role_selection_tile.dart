import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:r_square/app/core/constants/app_colors.dart';
import 'package:r_square/app/core/widgets/custom_text.dart';
import 'package:r_square/app/modules/common/choose_role/controller/choose_role_controller.dart';

class RoleSelectionTile extends StatelessWidget {
  final String title;
  final IconData icon;
  final ChooseRoleController controller;

  RoleSelectionTile({
    required this.title,
    required this.icon,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Obx(
      () {
        bool isSelected = controller.selectedRole.value == title;
        return GestureDetector(
          onTap: () => controller.selectRole(title),
          child: Container(
            width: Get.width,
            height: 70.h,
            decoration: BoxDecoration(
              color: isSelected ? AppColors.primaryappcolor : AppColors.grey,
              borderRadius: BorderRadius.circular(10.r),
            ),
            child: ListTile(
              leading: Icon(
                icon,
                color: isSelected ? Colors.white : AppColors.primaryappcolor,
              ),
              title: CText(
                text: title,
                fontSize: 14.sp,
                fontWeight: FontWeight.w400,
                color: isSelected ? Colors.white : AppColors.primaryappcolor,
              ),
              trailing: Radio<String>(
                value: title,
                groupValue: controller.selectedRole.value,
                onChanged: (value) {
                  controller.selectRole(value!);
                },
                fillColor: isSelected ? MaterialStateProperty.all(Colors.white) : MaterialStateProperty.all(AppColors.primaryappcolor),
                activeColor:isSelected ? Colors.white : AppColors.primaryappcolor,
              ),
            ),
          ),
        );
      },
    );
  }
}
