import 'package:get/get.dart';

class ChooseRoleController extends GetxController {
  
  var selectedRole = 'Admin'.obs;

  void selectRole(String role) {
    selectedRole.value = role;
  }
}