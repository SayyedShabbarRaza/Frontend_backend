class AppImages {
  // static const String greenulogo = 'assets/app_images/app_logo.png';
  static const String appLogo =
      'assets/app_images/Mask group (3).png';
  static const String bgasset = 'assets/app_images/BG Asset.png';
  static const String circleWavyCheck = 'assets/app_images/CircleWavyCheck.svg';
  static const String bgimage = 'assets/app_images/new-home-2409165_1280.jpg';
static const String onBoarding = 'assets/app_images/onBoarding.png';
static const String onBoarding2 = 'assets/app_images/Rectangle 6.png';
static const String onBoarding3 = 'assets/app_images/Rectangle 6 (1).png';
static const String loginImg = 'assets/app_images/login_image.png';
static const String oceanImg = 'assets/app_images/pexels-alex-staudinger-829197-1732414.png';
static const String propertyImg = 'assets/app_images/pexels-curtis-adams-1694007-4258279.png';
//////////////////// svg /////////////////////
static const String logo = 'assets/app_images/Rectangle 4.png';

}
