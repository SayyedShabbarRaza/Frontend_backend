import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_fonts.dart';

class AppTheme {
  // Light Theme
  static ThemeData lightTheme = ThemeData(
    primaryColor: AppColors.primaryappcolor,
    scaffoldBackgroundColor: AppColors.backgroundColor,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.appbarcolor,
      elevation: 0,
      titleTextStyle: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.bold,
        fontSize: AppFonts.large,
        color: AppColors.headingcolor,
      ),
      iconTheme: IconThemeData(
        color: AppColors.headingcolor,
      ),
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.bold,
        fontSize: AppFonts.extraLarge,
        color: AppColors.headingcolor,
      ),
      displayMedium: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.medium,
        fontSize: AppFonts.large,
        color: AppColors.headingcolor,
      ),
      bodyLarge: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.regular,
        fontSize: AppFonts.mediumSize,
        color: AppColors.textgreyColor,
      ),
      bodyMedium: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.regular,
        fontSize: AppFonts.small,
        color: AppColors.listtextcolor,
      ),
      labelLarge: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.bold,
        fontSize: AppFonts.mediumSize,
        color: AppColors.primarywhiteColor,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.textfieldcolor,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8.0),
        borderSide: BorderSide.none,
      ),
      hintStyle: const TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.regular,
        fontSize: AppFonts.mediumSize,
        color: AppColors.textgreyColor,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all(AppColors.primaryappcolor),
        foregroundColor: MaterialStateProperty.all(AppColors.primarywhiteColor),
        textStyle: MaterialStateProperty.all(const TextStyle(
          fontFamily: AppFonts.fontFamily,
          fontWeight: AppFonts.bold,
          fontSize: AppFonts.mediumSize,
        )),
        shape: MaterialStateProperty.all(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.0),
          ),
        ),
      ),
    ),
    buttonTheme: const ButtonThemeData(
      buttonColor: AppColors.primaryappcolor,
      textTheme: ButtonTextTheme.primary,
    ),
    dividerColor: AppColors.dividercolor, colorScheme: const ColorScheme(
      brightness: Brightness.light,
      primary: AppColors.primaryappcolor,
      onPrimary: AppColors.primarywhiteColor,
      secondary: AppColors.primarybluecolor,
      onSecondary: AppColors.primarywhiteColor,
      background: AppColors.backgroundColor,
      onBackground: AppColors.headingcolor,
      surface: AppColors.boxcolor,
      onSurface: AppColors.headingcolor,
      error: Colors.red,
      onError: AppColors.primarywhiteColor,
    ),
  );

  static ThemeData darkTheme = ThemeData(
    primaryColor: AppColors.primaryappcolor,
    scaffoldBackgroundColor: AppColors.primaryblackColor,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.darkgrey,
      elevation: 0,
      titleTextStyle: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.bold,
        fontSize: AppFonts.large,
        color: AppColors.primarywhiteColor,
      ),
      iconTheme: IconThemeData(
        color: AppColors.primarywhiteColor,
      ),
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.bold,
        fontSize: AppFonts.extraLarge,
        color: AppColors.primarywhiteColor,
      ),
      displayMedium: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.medium,
        fontSize: AppFonts.large,
        color: AppColors.primarywhiteColor,
      ),
      bodyLarge: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.regular,
        fontSize: AppFonts.mediumSize,
        color: AppColors.textgreyColor,
      ),
      bodyMedium: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.regular,
        fontSize: AppFonts.small,
        color: AppColors.grey,
      ),
      labelLarge: TextStyle(
        fontFamily: AppFonts.fontFamily,
        fontWeight: AppFonts.bold,
        fontSize: AppFonts.mediumSize,
        color: AppColors.primarywhiteColor,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all(AppColors.primaryappcolor),
        foregroundColor: MaterialStateProperty.all(AppColors.primarywhiteColor),
        textStyle: MaterialStateProperty.all(const TextStyle(
          fontFamily: AppFonts.fontFamily,
          fontWeight: AppFonts.bold,
          fontSize: AppFonts.mediumSize,
        )),
        shape: MaterialStateProperty.all(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.0),
          ),
        ),
      ),
    ),
    dividerColor: AppColors.dividercolor, colorScheme: const ColorScheme(
      brightness: Brightness.dark,
      primary: AppColors.primaryappcolor,
      onPrimary: AppColors.primarywhiteColor,
      secondary: AppColors.primarybluecolor,
      onSecondary: AppColors.primarywhiteColor,
      background: AppColors.primaryblackColor,
      onBackground: AppColors.primarywhiteColor,
      surface: AppColors.darkgrey,
      onSurface: AppColors.primarywhiteColor,
      error: Colors.red,
      onError: AppColors.primarywhiteColor,
    ),
  );
}