import 'package:get/get.dart';

var obscureText = true.obs;
var defaultObscureText = false.obs;