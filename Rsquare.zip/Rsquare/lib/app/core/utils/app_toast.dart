import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:r_square/app/core/constants/app_colors.dart';


appToast(String message){
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.TOP,
      timeInSecForIosWeb: 1,
      backgroundColor: AppColors.primaryappcolor,
      textColor: Colors.white,
      fontSize: 16.0
  );
}

Widget appLoader({Color? color}){
  return  Center(child: CircularProgressIndicator(color:color?? AppColors.primaryappcolor));
}