


class ApiService {
  static String baseURl = 'https://pharmacypro.wazirafghan.online/api';
  static String loginGeneral = '$baseURl/general/login';
  static String signupGeneral = '$baseURl/general/register';
  static String loginServiceProvider = '$baseURl/service-provider/login';
  static String signupServiceProvider = '$baseURl/service-provider/register';
  static String getAllClinicDoctors = '$baseURl/general/get-all-clinic-doctors';

}

dynamic headers = {
  'Content-Type': 'application/json',
};

// Future<Map<String, String>> getHeadersWithToken() async {

//   var token = await SharePrefServices.getAuthToken();
//   return {
//     'Content-Type': 'application/json',
//     'Authorization': 'Bearer $token',
//   };
// }