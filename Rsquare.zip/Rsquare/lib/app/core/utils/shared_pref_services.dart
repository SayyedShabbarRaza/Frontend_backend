import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';


class SharePrefServices {
  static saveLoggInUserIsGenral(bool val) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setBool('saveLoggInUserIsGenral', val);
  }

  static getLoggInUserIsGenral() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getBool('saveLoggInUserIsGenral');
  }

  static saveAuthToken(String val) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString('authToken', val);
  }

  static getAuthToken() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString('authToken');
  }

  static saveUserData(data) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString('userData', data);
  }

  static saveServiceProviderUserData(data) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString('serviceProviderUserData', data);
  }

  // static getUserData() async {
  //   SharedPreferences pref = await SharedPreferences.getInstance();
  //   var userRaw = pref.getString("userData");
  //   if (userRaw != null) {
  //     var user =GeneralUserModel.fromJson(jsonDecode(userRaw) as Map<String, dynamic>);
  //     return user;
  //   } else {
  //     return null;
  //   }
  // }

  // static getServiceProviderUserData() async {
  //   SharedPreferences pref = await SharedPreferences.getInstance();
  //   var userRaw = pref.getString("serviceProviderUserData");
  //   if (userRaw != null) {
  //     var user =ServiceProviderUserModel.fromJson(jsonDecode(userRaw) as Map<String, dynamic>);
  //     return user;
  //   } else {
  //     return null;
  //   }
  // }



}